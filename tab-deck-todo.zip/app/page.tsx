"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Trash2, X, ChevronDown, ChevronUp } from "lucide-react"

type ChecklistItem = {
  id: string
  text: string
  completed: boolean
}

type TodoCard = {
  id: string
  title: string
  body: string
  notes: string
  checklist: ChecklistItem[]
  tabId: string
}

type Tab = {
  id: string
  name: string
}

export default function TodoApp() {
  const [tabs, setTabs] = useState<Tab[]>([
    { id: "1", name: "個人" },
    { id: "2", name: "仕事" },
    { id: "3", name: "買い物" },
  ])
  const [activeTabId, setActiveTabId] = useState("1")
  const [cards, setCards] = useState<TodoCard[]>([])
  const [newTabName, setNewTabName] = useState("")
  const [showNewTabInput, setShowNewTabInput] = useState(false)

  const addTab = () => {
    if (newTabName.trim()) {
      const newTab: Tab = {
        id: Date.now().toString(),
        name: newTabName,
      }
      setTabs([...tabs, newTab])
      setNewTabName("")
      setShowNewTabInput(false)
      setActiveTabId(newTab.id)
    }
  }

  const deleteTab = (tabId: string) => {
    if (tabs.length > 1) {
      setTabs(tabs.filter((tab) => tab.id !== tabId))
      setCards(cards.filter((card) => card.tabId !== tabId))
      if (activeTabId === tabId) {
        setActiveTabId(tabs[0].id)
      }
    }
  }

  const addCard = () => {
    const newCard: TodoCard = {
      id: Date.now().toString(),
      title: "新しいカード",
      body: "",
      notes: "",
      checklist: [],
      tabId: activeTabId,
    }
    setCards([...cards, newCard])
  }

  const deleteCard = (cardId: string) => {
    setCards(cards.filter((card) => card.id !== cardId))
  }

  const updateCard = (cardId: string, updates: Partial<TodoCard>) => {
    setCards(cards.map((card) => (card.id === cardId ? { ...card, ...updates } : card)))
  }

  const filteredCards = cards.filter((card) => card.tabId === activeTabId)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-6 text-3xl font-bold text-gray-900 md:mb-8 md:text-4xl">Tab-Deck Todo</h1>

        <div className="mb-6 space-y-3">
          <div className="flex flex-wrap gap-2">
            {tabs.map((tab) => (
              <div key={tab.id} className="relative">
                <Button
                  variant={activeTabId === tab.id ? "default" : "outline"}
                  onClick={() => setActiveTabId(tab.id)}
                  className="h-12 px-6 text-base font-medium"
                >
                  {tab.name}
                </Button>
                {tabs.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteTab(tab.id)}
                    className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-red-500 p-0 text-white hover:bg-red-600"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}

            {showNewTabInput ? (
              <div className="flex gap-2">
                <Input
                  type="text"
                  placeholder="タブ名"
                  value={newTabName}
                  onChange={(e) => setNewTabName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addTab()}
                  className="h-12 w-32"
                  autoFocus
                />
                <Button onClick={addTab} className="h-12 bg-green-600 hover:bg-green-700">
                  追加
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowNewTabInput(false)
                    setNewTabName("")
                  }}
                  className="h-12"
                >
                  キャンセル
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => setShowNewTabInput(true)}
                className="h-12 border-2 border-dashed border-blue-300 bg-white hover:border-blue-500 hover:bg-blue-50"
              >
                <Plus className="mr-2 h-5 w-5" />
                タブを追加
              </Button>
            )}
          </div>
        </div>

        <Button
          onClick={addCard}
          className="mb-6 h-14 w-full bg-blue-600 text-lg font-medium hover:bg-blue-700 md:text-xl"
        >
          <Plus className="mr-2 h-6 w-6" />
          カードを追加
        </Button>

        <div className="space-y-6">
          {filteredCards.length === 0 ? (
            <Card className="border-2 border-dashed border-gray-300 bg-white/50">
              <CardContent className="p-12 text-center">
                <p className="text-lg text-gray-500">カードがありません。カードを追加してください。</p>
              </CardContent>
            </Card>
          ) : (
            filteredCards.map((card) => (
              <TodoCardComponent key={card.id} card={card} onUpdate={updateCard} onDelete={deleteCard} />
            ))
          )}
        </div>
      </div>
    </div>
  )
}

function TodoCardComponent({
  card,
  onUpdate,
  onDelete,
}: {
  card: TodoCard
  onUpdate: (cardId: string, updates: Partial<TodoCard>) => void
  onDelete: (cardId: string) => void
}) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [newChecklistItem, setNewChecklistItem] = useState("")

  const addChecklistItem = () => {
    if (newChecklistItem.trim()) {
      const newItem: ChecklistItem = {
        id: Date.now().toString(),
        text: newChecklistItem,
        completed: false,
      }
      onUpdate(card.id, { checklist: [...card.checklist, newItem] })
      setNewChecklistItem("")
    }
  }

  const toggleChecklistItem = (itemId: string) => {
    const updatedChecklist = card.checklist.map((item) =>
      item.id === itemId ? { ...item, completed: !item.completed } : item,
    )
    onUpdate(card.id, { checklist: updatedChecklist })
  }

  const completedCount = card.checklist.filter((item) => item.completed).length
  const totalCount = card.checklist.length

  return (
    <Card className="overflow-hidden border-2 border-gray-200 bg-white shadow-md hover:shadow-lg transition-shadow">
      {!isExpanded ? (
        <div className="flex items-center gap-3 p-3 border-b border-gray-200">
          <Input
            type="text"
            value={card.title}
            onChange={(e) => onUpdate(card.id, { title: e.target.value })}
            className="h-10 w-40 border-2 font-semibold text-sm"
            placeholder="タイトル"
          />

          <div className="h-8 w-px bg-gray-300" />

          <div className="flex items-center gap-2 min-w-24">
            <span className="text-xs font-medium text-gray-600">チェック:</span>
            <span className="text-sm font-semibold text-blue-600">
              {totalCount > 0 ? `${completedCount}/${totalCount}` : "0"}
            </span>
          </div>

          <div className="h-8 w-px bg-gray-300" />

          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-700 truncate">
              <span className="font-medium text-gray-600">本文: </span>
              {card.body || "なし"}
            </p>
          </div>

          <div className="h-8 w-px bg-gray-300" />

          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-600 truncate bg-gray-100 px-2 py-1 rounded">
              <span className="font-medium">備考: </span>
              {card.notes || "なし"}
            </p>
          </div>

          <div className="flex gap-1 shrink-0">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsExpanded(true)}
              className="h-10 w-10 text-blue-600 hover:bg-blue-50"
            >
              <ChevronDown className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(card.id)}
              className="h-10 w-10 text-red-600 hover:bg-red-50"
            >
              <Trash2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      ) : (
        <>
          <CardHeader className="border-b-2 border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50 p-4">
            <div className="flex items-center justify-between gap-3">
              <Input
                type="text"
                value={card.title}
                onChange={(e) => onUpdate(card.id, { title: e.target.value })}
                className="h-12 flex-1 border-2 text-lg font-bold"
                placeholder="カードタイトル"
              />
              <div className="flex gap-2 shrink-0">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsExpanded(false)}
                  className="h-12 w-12 text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                >
                  <ChevronUp className="h-6 w-6" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDelete(card.id)}
                  className="h-12 w-12 text-red-600 hover:bg-red-50 hover:text-red-700"
                >
                  <Trash2 className="h-6 w-6" />
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-4 md:p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-gray-900">チェックリスト</h3>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="項目を追加..."
                    value={newChecklistItem}
                    onChange={(e) => setNewChecklistItem(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addChecklistItem()}
                    className="h-12 flex-1 text-base"
                  />
                  <Button onClick={addChecklistItem} className="h-12 w-12 shrink-0 bg-green-600 hover:bg-green-700">
                    <Plus className="h-5 w-5" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {card.checklist.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 rounded-lg border-2 border-gray-200 bg-gray-50 p-3"
                    >
                      <Checkbox
                        checked={item.completed}
                        onCheckedChange={() => toggleChecklistItem(item.id)}
                        className="h-6 w-6 shrink-0"
                      />
                      <span
                        className={`flex-1 text-base ${item.completed ? "text-gray-400 line-through" : "text-gray-900"}`}
                      >
                        {item.text}
                      </span>
                    </div>
                  ))}
                  {card.checklist.length === 0 && (
                    <p className="text-center text-sm text-gray-400 py-4">項目がありません</p>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-gray-900">本文</h3>
                <Textarea
                  value={card.body}
                  onChange={(e) => onUpdate(card.id, { body: e.target.value })}
                  placeholder="本文を入力..."
                  className="min-h-64 resize-none border-2 text-base"
                />
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-gray-900">備考欄</h3>
                <Textarea
                  value={card.notes}
                  onChange={(e) => onUpdate(card.id, { notes: e.target.value })}
                  placeholder="備考を入力..."
                  className="min-h-64 resize-none border-2 text-base bg-gray-100"
                />
              </div>
            </div>
          </CardContent>
        </>
      )}
    </Card>
  )
}
